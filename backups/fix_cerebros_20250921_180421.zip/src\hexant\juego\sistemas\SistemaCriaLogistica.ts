﻿import type { World } from "../../tipos";

// La constructora lo hace en builderBrain.
// Dejar no-op para no interferir.
export function SistemaCriaLogistica(_w:World){ /* no-op */ }
