﻿import React from "react";
import { createRoot } from "react-dom/client";
import Aplicacion from "./Aplicacion";

const root = document.getElementById("root")!;
createRoot(root).render(<Aplicacion />);
