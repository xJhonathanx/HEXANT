﻿/** SistemaPercepcion  Lote D: placeholder (no-op). */
import { World } from "../../tipos";
export function SistemaPercepcion(_w:World, _dt:number){ /* no-op por ahora */ }
