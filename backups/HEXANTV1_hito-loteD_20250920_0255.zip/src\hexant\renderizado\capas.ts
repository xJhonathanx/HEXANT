﻿export enum Capas {
  Mundo = 0,
  FX = 1,
  HUD = 2,
}
