﻿export { MotorDeRender } from "./MotorDeRender";
