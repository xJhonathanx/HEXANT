import type { World } from "../../tipos";
import { CARRY_PER_TRIP, EGGS_NEED_UND } from "../configuracion/predeterminados";

/**
 * Enfermeras: mueven huevos desde la reina hasta el hex objetivo
 * y los alimentan hasta alcanzar EGGS_NEED_UND (=25).
 * No construyen; sólo colocan y alimentan.
 */
export function SistemaNurse(w: World, _cfg?: unknown) {
  const eggs = (w as any).eggs as any[] | undefined;
  if (!eggs || eggs.length === undefined) return;

  const q = w.hexes.find(h => (h as any).host === "queen") as any;
  if (!q) return;

  // Hex objetivo = el más reciente que no sea la reina y no completado (builder lo prepara)
  const target = w.hexes.find(h => (h as any).host !== "queen" && !(h as any).completed) as any | undefined;

  for (const a of (w.ants as any[])) {
    if (a.kind !== "nurse") continue;

    a.state ??= "idle";
    a.carryEgg ??= false;
    a.carryingUnits ??= 0;

    switch (a.state) {
      case "idle": {
        const eggsAtQueen = eggs.some(e => e.state === "atQueen");
        if (eggsAtQueen && target) a.state = "toQueenEgg";
        else hoverAround(a, q.cx, q.cy);
        break;
      }

      case "toQueenEgg": {
        if (approach(a, q.cx, q.cy, 0.06)) {
          const eg = eggs.find(e => e.state === "atQueen");
          if (eg) {
            eg.state = "carried";
            eg.carrierId = a.id;
            a.carryEgg = true;
            a.state = "toTargetHex";
          } else {
            a.state = "idle";
          }
        }
        break;
      }

      case "toTargetHex": {
        if (!target) { a.state = "idle"; break; }
        if (approach(a, target.cx, target.cy, 0.06)) {
          // Visual: colocar spot en el hex (se usa por el render actual)
          target.eggs ??= { spots: [], born: 0, active: true, fed: 0, tStart: (w as any)._tick ?? 0 };
          const spots = target.eggs.spots as Array<{ x: number, y: number }>;

          const idx = target.eggs.born % 6;
          const ang = Math.PI / 3 * idx + Math.PI / 6;
          const ring = target.sidePx * 0.78; // interior cerca de aristas
          const px = target.cx + Math.cos(ang) * ring;
          const py = target.cy + Math.sin(ang) * ring;

          spots.push({ x: px, y: py });
          target.eggs.born++;

          // Egg entidad pasa a incubar en este hex
          const eg = eggs.find(e => e.state === "carried" && e.carrierId === a.id);
          if (eg) {
            eg.state = "incubating";
            eg.hexId = target.id; eg.x = px; eg.y = py;
            eg.fed = eg.fed ?? 0;
            delete eg.carrierId;
          }

          a.carryEgg = false;
          a.state = "feedEgg";
        }
        break;
      }

      case "feedEgg": {
        // alimentar el primer huevo en este hex que aún no alcance EGGS_NEED_UND
        const eg = eggs.find(e =>
          e.state === "incubating" &&
          e.hexId === (target?.id) &&
          (e.fed ?? 0) < EGGS_NEED_UND);

        if (!eg) { a.state = "idle"; break; }

        const need = EGGS_NEED_UND - (eg.fed ?? 0);
        const take = Math.min(need, CARRY_PER_TRIP, (w as any).stockFood ?? 0);

        if (take > 0) {
          (w as any).stockFood = ((w as any).stockFood ?? 0) - take;
          eg.fed = (eg.fed ?? 0) + take;
        }

        if ((eg.fed ?? 0) >= EGGS_NEED_UND) {
          // huevo listo para eclosión (el sistema de cría decidirá el hatch)
          a.state = "idle";
        }
        break;
      }
    }
  }
}

function approach(a: any, tx: number, ty: number, k = 0.06) {
  const dx = tx - a.x, dy = ty - a.y;
  a.vx = (a.vx ?? 0) * 0.9 + dx * k;
  a.vy = (a.vy ?? 0) * 0.9 + dy * k;
  a.x += a.vx; a.y += a.vy;
  return dx * dx + dy * dy < 9;
}

function hoverAround(a: any, cx: number, cy: number) {
  const t = (a._t = ((a._t ?? 0) + 0.06));
  const r = 18;
  const tx = cx + Math.cos(t + a.id) * r;
  const ty = cy + Math.sin(t + a.id) * r;
  approach(a, tx, ty, 0.04);
}
