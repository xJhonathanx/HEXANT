﻿# Placeholder Lote A
Esta carpeta se llenará en los lotes siguientes. Mantener nombres sencillos.
